#include <iostream>
#include <vector>
#include <cstdint>
#include <utility>
#include <map>

extern std::vector<uint32_t>LLC_ACCESSES;
extern std::vector<uint32_t>LLC_EVICTIONS;
extern std::vector<uint32_t>LLC_MISS;
extern std::vector<uint32_t>LLC_HIT;
extern std::vector<std::pair<double,uint32_t>>hotness;
extern std::uint32_t LLC_TotalAccesses,LLC_TotalEvictions,LLC_TotalMisses,LLC_TotalHits,ashu_30k;
extern std::map<uint32_t, std::vector<uint32_t>> suryamap;
extern int flag_ashu;